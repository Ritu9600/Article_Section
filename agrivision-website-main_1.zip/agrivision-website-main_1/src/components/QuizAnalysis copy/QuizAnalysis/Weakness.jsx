import React from "react";
import styled from "styled-components";
import Paper from "@mui/material/Paper";
import Card from "./Card";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import { makeStyles } from "@material-ui/core/styles";
import Container from "@mui/material/Container";
import WeakConcepts from "./WeakConcepts";
import WeaknessGraph from "./WeaknessGraph";
// import Dashbar from "./DashBar";

const useStyles = makeStyles((theme) => ({
  paper: {
    padding: theme.spacing(1),
    textAlign: "center",
    color: theme.palette.text.secondary,
  },
}));

const Item = styled(Paper)(() => ({
  textAlign: "center",
}));

function Weakness() {
  return (
    <Wrapper>
      <RowOne>
        <WeaknessGraphContainer>
          <WeaknessGraph />
        </WeaknessGraphContainer>
        <CardContainer>
          <Card />
        </CardContainer>
      </RowOne>
      <RowTwo>
        <WeakConceptsContainer>
          <WeakConcepts />
        </WeakConceptsContainer>
      </RowTwo>
    </Wrapper>
  );
}

// const section = {
//   height: "100%",
//   paddingTop: 5,
//   backgroundColor: "#fff",
// };

// function Weakness() {
//   return (
//     <Box sx={{ width: "100%" }}>
//       <Grid
//         container
//         rowSpacing={1}
//         columnSpacing={{ xs: 1, sm: 2, md: 3 }}
//         alignItems="baseline"
//         justifyContent="stretch"
//       >
//         <Grid item xs={7}>
//           <WeaknessGraph />
//         </Grid>
//         <Grid item xs={5}>
//           <div style={section}>
//             <Card />
//           </div>
//         </Grid>
//         <Grid item xs>
//           <div style={section}>
//             <Card />
//           </div>
//         </Grid>
//       </Grid>
//     </Box>
//   );
// }

export default Weakness;

const Wrapper = styled.div`
  height: 100%;
  display: flex;
  flex-direction: column;
  flex: 1;
`;

const RowOne = styled.div`
  display: flex;
  flex: 1;
`;

const RowTwo = styled.div`
  display: flex;
  flex: 1;
  overflow-y: auto;
`;

const WeaknessGraphContainer = styled.div`
  width: 60%;
  flex-grow: 1;
  // flex-shrink: 0;
  margin: 10px;
`;

const CardContainer = styled.div`
  width: 40%;
  flex-grow: 1;
  margin: 10px;
`;

const WeakConceptsContainer = styled.div`
  flex-grow: 1;
  margin: 10px;
`;
