import React from "react";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";

const currentUserId = 3; //Hardcoded for now;
const TablePage = (props) => {
  const data = {
    columns: [
      {
        label: "Rank",
        field: "id",
        sort: "asc",
      },
      {
        label: "Name",
        field: "first",
        sort: "asc",
      },
      {
        label: "Score",
        field: "last",
        sort: "asc",
      },
    ],
    rows: [
      {
        Rank: 1,
        Name: "Arjun Bharadwaj",
        Score: "98",
        UserId: 1,
      },
      {
        Rank: 2,
        Name: "Arjun Bharadwaj",
        Score: "98",
        UserId: 2,
      },
      {
        Rank: 3,
        Name: "Arjun Bharadwaj",
        Score: "98",
        UserId: 3,
      },
      {
        Rank: 4,
        Name: "Arjun Bharadwaj",
        Score: "98",
        UserId: 4,
      },
      {
        Rank: 5,
        Name: "Arjun Bharadwaj",
        Score: "98",
        UserId: 5,
      },
      {
        Rank: 6,
        Name: "Arjun Bharadwaj",
        Score: "98",
        UserId: 6,
      },
      {
        Rank: 7,
        Name: "Arjun Bharadwaj",
        Score: "98",
        UserId: 7,
      },
    ],
  };

  return (
    <TableContainer component={Paper}>
      <Table
        sx={{
          minWidth: 650,
          "& .MuiTableCell-head": {
            fontWeight: 700,
          },
        }}
        stickyHeader
        aria-label="simple table"
      >
        <TableHead>
          <TableRow>
            {/* {data.columns.map((columns) => (
              <TableCell align="left">{columns.label}</TableCell>
            ))} */}

            <TableCell align="left">Rank</TableCell>
            <TableCell align="center">Name</TableCell>
            <TableCell align="center">Score</TableCell>
          </TableRow>
        </TableHead>

        <TableBody>
          {data.rows.map((row) => (
            <TableRow
              key={row.Rank}
              sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
              selected={row.UserId === currentUserId} // Change logic to equate row.user-id to current user
            >
              <TableCell component="th" scope="row">
                {row.Rank}
              </TableCell>
              <TableCell align="center">{row.Name}</TableCell>
              <TableCell align="center">{row.Score}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

export default TablePage;
