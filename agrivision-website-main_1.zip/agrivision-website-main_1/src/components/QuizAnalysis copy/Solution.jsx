import React from 'react';
import SolLayout from '../Quiz/Sol_Layout';

function Solution() {
	return <div>
		<SolLayout/>
	</div>;
}

export default Solution;
