import { useState } from "react";
import styled from "styled-components";
import { OutlinedButton } from "./Styled";
import ArrowBackIosIcon from "@material-ui/icons/ArrowBackIos";
import { Link } from "react-router-dom";

const Main = () => {
  const [activeSection, setActiveSection] = useState({
    overview: true,
    weakness: false,
    solution: false,
    comparison: false,
  });
  const inactive = {
    overview: false,
    weakness: false,
    solution: false,
    comparison: false,
  };

  return (
    <MainCont>
      <SectionHeader>
        <div className="sections">
          <Link to={"/analysis/overview"} className="link">
            <SectionButton
              active={activeSection.overview}
              onClick={() => {
                setActiveSection({
                  ...inactive,
                  overview: true,
                });
              }}
            >
              <span className="laptop"> Overview</span>
              <span className="phone">Overview</span>
            </SectionButton>
          </Link>

          <Link to={"/analysis/solution"} className="link">
            <SectionButton
              active={activeSection.solution}
              onClick={() => {
                setActiveSection({
                  ...inactive,
                  solution: true,
                });
              }}
            >
              <span className="laptop">Solution</span>
              <span className="phone">Solution</span>
            </SectionButton>
          </Link>

          <Link to={"/analysis/weakness"} className="link">
            <SectionButton
              active={activeSection.weakness}
              onClick={() => {
                setActiveSection({
                  ...inactive,
                  weakness: true,
                });
              }}
            >
              <span className="laptop"> Weakness</span>
              <span className="phone">Weakness</span>
            </SectionButton>
          </Link>

          <Link to={"/analysis/comparison"} className="link">
            <SectionButton
              active={activeSection.comparison}
              onClick={() => {
                setActiveSection({
                  ...inactive,
                  comparison: true,
                });
              }}
            >
              <span className="laptop">Comparison</span>
              <span className="phone">Comparison</span>
            </SectionButton>
          </Link>
        </div>
      </SectionHeader>
    </MainCont>
  );
};

const SectionHeader = styled.div`
  width: 100%;
  padding: 12px 16px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  @media (max-width: 700px) {
    padding: 12px 8px;
  }
  @media (max-width: 650px) {
    padding: 12px 4px;
  }
  @media (max-width: 400px) {
    padding: 10px 0px;
  }
`;

const MainCont = styled.div`
  position: relative;
  width: 100%;
  //height: 100%;
  padding: 0px 12px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  grid-column: 1/3;
  grid-column: 1/3;
`;
const Toggle = styled.div`
  position: absolute;
  top: 70px;
  right: 0px;
  width: 30px;
  height: 36px;
  border-top-left-radius: 50%;
  border-bottom-left-radius: 50%;
  background-color: white;
  cursor: pointer;
  display: flex;
  justify-content: center;
  align-items: center;
  color: #1bbc9b;
  border: 2px solid #1bbc9b;
  border-right: none;
  /* transform: translateX(100%); */
  svg {
    margin-left: 12px;
  }
`;
const Button = styled(OutlinedButton)`
  margin-bottom: 32px;
  margin-right: 12px;
  padding: 10px 16px;
  transition: all 0.3s ease-in-out;
  @media (max-width: 850px) {
    padding: 8px 8px;
    margin-right: 10px;
  }
  @media (max-width: 780px) {
    padding: 8px 4px;
    margin-right: 8px;
  }
  @media (max-width: 750px) {
    margin-right: 6px;
    font-size: 14px;
    margin-bottom: 24px;
  }
  @media (max-width: 430px) {
    font-size: 12px;
  }
  @media (max-width: 360px) {
    font-size: 10px;
  }

  &:hover {
    background: linear-gradient(86.94deg, #1bbc9b 0%, #1bbc9b 0.01%, #16a086 100%);
    color: white;
  }
`;
const ButtonContainer = styled.div`
  margin-top: auto;
  display: flex;
  padding: 0px 12px;
  @media (max-width: 680px) {
    width: 100%;
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 8px;
    align-items: center;
    div {
      width: 100%;
      justify-self: center;
      margin-right: 0px;
      margin-bottom: 0px;
      justify-content: center;
      &:nth-child(2n + 1) {
        grid-column: 1/2;
      }
      &:nth-child(2n) {
        grid-column: 2/3;
      }
    }
  }
  @media (max-width: 380px) {
    padding: 0px 0px;
  }
`;

const SectionButton = styled.button`
  padding: 6px 16px;
  font-size: 16px;
  background-color: #e5f8ff;
  border: 2px solid ${(props) => (props.active ? "#1bbc9b" : "#e5f8ff")};
  border-radius: 4px;
  color: #1bbc9b;
  font-weight: 500;
  cursor: pointer;
  margin: 0px 16px;
  .laptop {
    display: inline-block;
  }
  .phone {
    display: none;
  }
  @media (max-width: 750px) {
    margin: 0px 8px;
  }
  @media (max-width: 700px) {
    margin: 0px 4px;
    padding: 6px 12px;
  }
  @media (max-width: 650px) {
    margin: 0px 4px;
    padding: 6px 24px;
    .laptop {
      display: none;
    }
    .phone {
      display: inline-block;
    }
  }
  @media (max-width: 600px) {
    font-size: 14px;
  }
  @media (max-width: 500px) {
    padding: 6px 16px;
  }
  @media (max-width: 450px) {
    padding: 6px 10px;
  }
  @media (max-width: 400px) {
    padding: 2px 8px;
    font-size: 12px;
    margin: 0px 2px;
  }
`;
export default Main;
