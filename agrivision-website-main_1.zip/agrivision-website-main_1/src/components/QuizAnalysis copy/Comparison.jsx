import React from 'react';

function Comparison() {
	return <div></div>;
}

export default Comparison;
