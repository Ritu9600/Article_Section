import { useState, useEffect } from "react";
import { BrowserRouter as Router, Switch, Route, Link, Redirect } from "react-router-dom";
import styled from "styled-components";
import Header from "./Header";
import Main from "./Main";
//functionality demo
import data from "./dummy-question-data";
import Overview from "./Overview";
import Solution from "./Solution";
import Weakness from "./Weakness";
import Comparison from "./Comparison";

const numOfPhysicsQues = data.physics.length;
const numOfChemistryQues = data.chemistry.length;
const addSomeFields = (quesArray) => {
  let newData = quesArray.map((question) => ({
    ...question,
    status: "not-visited",
    answered: null,
  }));
  return newData;
};

const Layout = () => {
  const [isSideBarOpen, setIsSideBarOpen] = useState({
    byClick: true,
    bySize: false,
  });
  const handleToggleClick = () => {
    setIsSideBarOpen({ ...isSideBarOpen, byClick: !isSideBarOpen.byClick });
  };
  const [currentQuestion, setCurrentQuestion] = useState(null);

  const [allQuestions, setAllQuestions] = useState(null);
  const questionArray = (data) => {
    let physicsQuestions = addSomeFields(data.physics);
    let chemistryQuestions = addSomeFields(data.chemistry);
    let mathsQuestions = addSomeFields(data.maths);
    let QuesArray = [...physicsQuestions, ...chemistryQuestions, ...mathsQuestions];
    let IndexedData = QuesArray.map((ques, index) => {
      return { ...ques, index: index };
    });
    return IndexedData;
  };
  useEffect(() => {
    setAllQuestions(questionArray(data));
    setCurrentQuestion({
      ...questionArray(data)[0],
      status: "not-answered",
    });
    // eslint-disable-next-line
  }, []);

  const [currentSection, setCurrentSection] = useState({
    currentSection: "overview",
  });

  return (
    <Wrapper>
      <Header />
      {allQuestions && (
        <Container>
          <Main />

          <Tabs>
            <Switch>
              <Route
                exact
                path={`/analysis`}
                render={() => <Redirect replace to={`/analysis/overview`} />}
              />
              <Route path={"/analysis/overview"} component={Overview} />
              <Route path={"/analysis/solution"} component={Solution} />
              <Route path={"/analysis/weakness"} component={Weakness} />
              <Route path={"/analysis/comparison"} component={Comparison} />
            </Switch>
          </Tabs>
        </Container>
      )}
    </Wrapper>
  );
};

const Container = styled.div`
  height: calc(100% - 62px);
  width: 100%;
  // display: grid;
  // grid-template-columns: 2.5fr 1fr;
  display: flex;
  flex-direction: column;
  position: relative;
`;
const Wrapper = styled.div`
  width: 100%;
  height: 100vh;
`;

const Tabs = styled.div`
  width: 100%;
  height: 100%;
`;
export default Layout;
