import { useState, useEffect } from "react";
import styled from "styled-components";
import Guidelines from "./Guidelines";
import Main from "./Main";
import Payment from "./Payment";
import Upload from "./Upload";
import Data from "./Data";
import Navbar from "./Navbar";
import Footer from "../global/Footer";
//functionality demo


const Layout = () => {
  const [activeSection, setActiveSection] = useState({
    guidelines: true,
   upload:false,
    data: false,
    payment: false,
  });

  return (
    <Wrapper>
      <Navbar/>
      <Container>
        <Main activeSection={activeSection} setActiveSection={setActiveSection} />

        <Tabs>
          {activeSection.guidelines ? <Guidelines /> : null}
          {activeSection.upload ? <Upload /> : null}
          {activeSection.data ? <Data /> : null}
          {activeSection.payment ? <Payment /> : null}
        </Tabs>
      </Container>
      <Footer/>
    </Wrapper>
   
  );
};

const Container = styled.div`
 padding-bottom: 30%;
  width: 100%;
  // display: grid;
  // grid-template-columns: 2.5fr 1fr;
  display: flex;
  flex-direction: column;
  position: relative;
`;
const Wrapper = styled.div`
  width: 100%;
  height: 100vh;
`;

const Tabs = styled.div`
  width: 100%;
  height: 100%;
`;
export default Layout;