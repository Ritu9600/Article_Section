import React from 'react';
import "./article.css";
import styled from "styled-components";
import { Button } from "../global/Global";
import { Link } from "react-router-dom";
import Upload from './Upload';
import Main from "./Main";
import { useState } from "react";

const Guidelines = () => {
  const [activeSection, setActiveSection] = useState({
    guidelines: true,
   upload:false,
    data: false,
    payment: false,
  }
  );
  const Guidelinesdata= [
    {
      
      concepts: [
        "1. Order will be placed 1 hr prior to the specified time. ",
       "2. Amount will be deducted from the bank account and if there any extra charges applied before ordering the food, a notification will be popped up to pay the amount. ",
        
        "3. Amount will be deducted from the bank account and if there any extra charges applied before ordering the food, a notification will be popped up to pay the amount. ",
      ],
    },
    {
      
      concepts: [
        "4. Amount will be deducted from the bank account and if there any extra charges applied before ordering the food, a notification will be popped up to pay the amount. ",
        "5. Amount will be deducted from the bank account and if there any extra charges applied before ordering the food, a notification will be popped up to pay the amount.  ",
        "6. Amount will be deducted from the bank account and if there any extra charges applied before ordering the food, a notification will be popped up to pay the amount. ",
      ],
    },
    {
    
      concepts: [
        "7.Amount will be deducted from the bank account and if there any extra charges applied before ordering the food, a notification will be popped up to pay the amount. ",
      ],
    },
  ];
	return (
        <div>
		<h4 className="submission-head">Submission Guidelines</h4>
		<GuidelinesContainer>
      
      <Concept>
        {Guidelinesdata.map((data) => (
          <>
            {data.concepts.map((concept) => (
              <Description>{concept}</Description>
            ))}
          </>
        ))}
      </Concept>
      <Concept1>
      <form className="des_check">
      <input type="checkbox" />
      <label className="check">I have read all the Guidelines and I acknowledge that I have Completed all the Requirments 
      </label>
    </form>
   
    <div className="nextpage">
          
            <StyledButton
             active={activeSection.guidelines}
             onClick={() => {
               setActiveSection({
                 upload: true,
               });
             }}>Next</StyledButton>
         
        </div>
        </Concept1>
    </GuidelinesContainer>
    </div>
	);
}



const GuidelinesContainer = styled.div`
  width: 100%;
  overflow: auto;
  font-size: 3vh;
`;

const Header = styled.div`
  border-bottom: 1px solid #1bbc9b;
  color: #1bbc9b;
  font-family: Inter;
  font-style: normal;
  padding-left:2%;
  padding-top: 3%;
  font-weight: 600;
  font-size: 22px;
`;

const Concept = styled.div`
 
  @media(max-width:600px){
    width: 90%;
    padding-left: 10%;
    overflow-y: auto;
  }

  @media(min-width:600px)and (max-width:1100px){
    width: 85%;
    padding-left: 20%;
    overflow-y: auto;
  }
  
  @media(min-width:1100px){
    width: 75%;
    padding-left: 29%;
    overflow-y: auto;
  }
  
`;
const Concept1 = styled.div`
 
  @media(max-width:600px){
    width: 90%;
    overflow-y: auto;
  }
  
  @media(min-width:600px)and (max-width:1100px){
    width: 80%;
    padding-left: 0%;
    overflow-y: auto;
  }
  @media(min-width:1100px){
    width: 75%;
    padding-left:11%;
    overflow-y: auto;
  }
  
`;

const StyledButton = styled(Button)`
  background: linear-gradient(
    86.94deg,
    #1bbc9b 0%,
    #1bbc9b 0.01%,
    #16a086 100%
  );
  color: white;
  padding-left:5%;
  padding-right:5%;
  font-size:18px;
  margin-left: 20%;
 
`;

const Description = styled.div`
width: 100%;
padding: 2%;
padding-left:1.2%;
font-size: 13px;
font-weight:500;
`;
export default Guidelines;