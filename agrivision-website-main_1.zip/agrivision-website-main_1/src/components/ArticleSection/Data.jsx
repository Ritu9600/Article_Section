import React from 'react';
import styled from "styled-components";
import { Link } from "react-router-dom";
import { Button } from "../global/Global";
import {  Row, Col } from "reactstrap";
import "./article.css";
function Data() {
	return (
		<div>
		<div><h4 className="submission-head">Enter Your Details</h4> </div>
         <div className="details_box">
		
		<Row className="row_3">
		 <Col sm="6">
		 <InputField>
          <label htmlFor='text'>First Name</label>
          <input
            type='text'
            name='title'
            id='title'
          />
        </InputField>
		</Col>
		<Col sm="6">
		 <InputField>
          <label htmlFor='text'>Last Name</label>
          <input
            type='text'
            name='title'
            id='title'
          />
        </InputField>
		</Col>
		</Row>
		<Row className="row_3">
		 <Col sm="6">
		 <InputField>
          <label htmlFor='text'>Institute Name</label>
          <input
            type='text'
            name='title'
            id='title'
          />
        </InputField>
		</Col>
		<Col sm="6">
		 <InputField>
          <label htmlFor='text'>Department</label>
          <input
            type='text'
            name='title'
            id='title'
          />
        </InputField>
		</Col>
		</Row>
		<Row className="row_3">
		 <Col sm="6">
		 <InputField>
          <label htmlFor='text'>Designation</label>
          <input
            type='text'
            name='title'
            id='title'
          />
        </InputField>
		</Col>
		<Col sm="6">
		 <InputField>
          <label htmlFor='text'>City</label>
          <input
            type='text'
            name='title'
            id='title'
          />
        </InputField>
		</Col>
		</Row>
		<Row className="row_3">
		 <Col sm="6">
		 <InputField>
          <label htmlFor='text'>Email</label>
          <input
            type='text'
            name='title'
            id='title'
          />
        </InputField>
		</Col>
		<Col sm="6">
		 <InputField>
          <label htmlFor='text'>Mobile No.</label>
          <input
            type='text'
            name='title'
            id='title'
          />
        </InputField>
		</Col>
		</Row>
		 </div>
		 <div className="btns_data" >
        <Row >
          <Col>
        <span className="data_next">
          <Link to="/todetails">
            <StyledButton1>Back</StyledButton1>
          </Link>
        </span>
        </Col>
        <Col>
        <span className="data_next">
          <Link to="/topayment">
            <StyledButton>Next</StyledButton>
          </Link>
        </span>
        </Col>
        </Row>
        </div>
		</div>
	);
}
export default Data;


export const InputField = styled.div`
  width: 100%;
  padding-left:15%;
  
  label {
    font-size: 16px;
    font-weight: 600;
  }
  input {
    width: 100%;
    font-size: 16px;
    border-radius: 8px;
    border: 1px solid black;
    outline: none;
    padding: 2%;
    margin-top: 4%;

  }
`;

const StyledButton = styled(Button)`
  background: linear-gradient(
    86.94deg,
    #1bbc9b 0%,
    #1bbc9b 0.01%,
    #16a086 100%
  );
  color: white;
  padding-left:35%;
  padding-right:35%;
`;


const StyledButton1 = styled(Button)`
background: #E8F3FF;
border: 2px solid #1bbc9b;
  color:  linear-gradient(
    86.94deg,
    #1bbc9b 0%,
    #1bbc9b 0.01%,
    #16a086 100%
  );
  padding-left:35%;
  padding-right:35%;
`;
