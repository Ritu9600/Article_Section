import React from 'react';
import styled from "styled-components";
import { Link } from "react-router-dom";
import { Button } from "../global/Global";
import {  Row, Col } from "reactstrap";
import "./article.css";
import  Navbar from './Navbar';
import SectionHead from './Main';
import Footer from '../global/Footer';

function Upload() {
	return (
        <div>
          
          
		<div><h4 className="submission-head">Upload Submission File</h4> </div>
    <div className="cont_upload">
        <InputField>
          <label htmlFor='text'>Title of Article</label>
          <input
            type='text'
            name='title'
            id='title'
          />
        </InputField>
        <InputField>
          <label htmlFor='dropdown'>Select File Type</label>
          <div >
           <select className="select2" name="dropdown" id="dropdown3">
             <option value="value1">   </option>
           </select>
         </div>
        </InputField>
        <div>
        <div id="dropContainer" >
    <header><span class="icon3"><i class="fas fa-cloud-upload-alt"></i> <input type="file"hidden/></span>
    
    Drag & Drop a file here to begin Upload </header>
        </div>
        </div>
        <div className="btns">
        <Row >
          <Col>
        <span className="upload_next">
          <Link to="/articles">
            <StyledButton1>Back</StyledButton1>
          </Link>
        </span>
        </Col>
        <Col>
        <span className="upload_next">
          <Link to="/todata">
            <StyledButton>Next</StyledButton>
          </Link>
        </span>
        </Col>
        </Row>
        </div>
      </div>
     
		</div>
	);
}
export default Upload;



export const InputField = styled.div`
  width: 100%;
  margin: 24px 0px;
 
  label {
    font-size: 16px;
    font-weight: 600;
  }
  input {
    width: 100%;
    font-size: 16px;
    border-radius: 8px;
    border: 2px solid lightgrey;
    outline: none;
    padding: 2%;
    margin-top: 4%;

  }
`;

const StyledButton = styled(Button)`
  background: linear-gradient(
    86.94deg,
    #1bbc9b 0%,
    #1bbc9b 0.01%,
    #16a086 100%
  );
  color: white;
  padding-left:35%;
  padding-right:35%;
`;


const StyledButton1 = styled(Button)`
background: #E8F3FF;
border: 2px solid #1bbc9b;
  color:  linear-gradient(
    86.94deg,
    #1bbc9b 0%,
    #1bbc9b 0.01%,
    #16a086 100%
  );
  padding-left:35%;
  padding-right:35%;
`;
