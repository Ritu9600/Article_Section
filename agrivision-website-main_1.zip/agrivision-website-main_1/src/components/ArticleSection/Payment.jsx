import React from 'react';


function Payment1() {
	return (
		<div><h4 className="submission-head">Payment</h4> </div>
		
	);
}
export default Payment1;