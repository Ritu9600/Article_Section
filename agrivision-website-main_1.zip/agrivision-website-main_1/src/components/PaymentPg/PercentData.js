const PercentData=[{
    id: 5,
    percentage: 50
},
{
    id: 4,
    percentage: 50
},
{
    id: 3,
    percentage: 0
},
{
    id: 2,
    percentage: 0
},
{
    id: 1,
    percentage: 0
},
];

export default PercentData;