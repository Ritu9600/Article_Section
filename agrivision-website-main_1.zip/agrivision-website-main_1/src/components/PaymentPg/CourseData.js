const CourseData=[{
    id: 5,
    title:"Thermodynamics",
    studentsEnrolled: '1.2k',
    rating:4

},
{
    id: 4,
    title:"Equilibrium",
    studentsEnrolled: '2.2k',
    rating:5
},
{
    id: 3,
    title:"Kinetics",
    studentsEnrolled: '0.2k',
    rating:5
}
];

export default CourseData;