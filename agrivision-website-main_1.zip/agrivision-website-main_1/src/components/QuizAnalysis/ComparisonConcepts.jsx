import React from "react";
import styled from "styled-components";
import "./Comparison.css";
const weakConceptsData = [
  {
    topic: "Topic",
    concepts: [
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi ullamcorper vulputate lectus,",
      " id sodales ligula facilisis eu. Vivamus in convallis dolor. Cras a risus eu neque porttitor ",
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi ullamcorper vulputate lectus, id sodales ligula facilisis eu. Vivamus in convallis dolor. Cras a risus eu neque porttitor "
    ],
  },
  
];
const strengthConceptsData = [
    {
      topic: "Topic",
      concepts: [
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi ullamcorper vulputate lectus,",
        " id sodales ligula facilisis eu. Vivamus in convallis dolor. Cras a risus eu neque porttitor ",
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi ullamcorper vulputate lectus, id sodales ligula facilisis eu. Vivamus in convallis dolor. Cras a risus eu neque porttitor "
      ],
    },
    
  ];

function ComparisonConcepts() {
  return (
    <ConceptContainer>
      <Header>
        <div className="number">Comparitive strengths</div>
      </Header>
      <Concept>
        {strengthConceptsData.map((data) => (
          <>
            <Topic>{data.topic}</Topic>
            {data.concepts.map((concept) => (
              <Description>{concept}</Description>
            ))}
          </>
        ))}
      </Concept>
      <Header1>
        <div className="number1">Comparitive Weakness</div>
      </Header1>
      <Concept>
        {weakConceptsData.map((data) => (
          <>
            <Topic>{data.topic}</Topic>
            {data.concepts.map((concept) => (
              <Description>{concept}</Description>
            ))}
          </>
        ))}
      </Concept>
    </ConceptContainer>
  );
}

export default ComparisonConcepts;

const ConceptContainer = styled.div`
  width: 100%;
  overflow: auto;
  font-size: 3vh;
`;

const Header = styled.div`
  border-bottom: 1px solid #1bbc9b;
  color: #1bbc9b;
  font-family: Inter;
  font-style: normal;
  padding-left:2%;
  font-weight: 600;
  font-size: 22px;
`;

const Header1 = styled.div`
  border-bottom: 1px solid #FE5252;
  color: #FE5252;
  font-family: Inter;
  font-style: normal;
  font-weight: 600;
  font-size:22px;
 padding-left:2%;
`;

const Concept = styled.div`
  width: 100%;
  padding: 12px 16px;
  overflow-y: auto;
`;

const Topic = styled.div`
  width: 100%;
  padding: 10px 16px;
  font-weight: 700;
  font-size:18px;
`;

const Description = styled.div`
  width: 100%;
  padding: 0.3%;
  padding-left:1.2%;
  font-size: 13px;
  font-weight:500;
`;
