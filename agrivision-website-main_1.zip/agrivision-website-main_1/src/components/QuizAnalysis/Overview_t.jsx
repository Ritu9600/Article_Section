import React from 'react'
import { useState, useEffect } from 'react';
import styled from 'styled-components';
import Card from '@mui/material/Card';

function Overview() {
    return (
        <div className='overview'>
            <div className='home__row'>
                <GeneralStats 
                    correct={}
                    incorrect={}
                    skipped={}            
                />
                <TimeDistribution
                    totalTimeTaken={}
                    timeDistribution={}
                />
            </div>

            <div className='home__row'>
                <Rank 
                    rankInformation={}
                />
                <TopicAnalysis
                    topicInformation={}
                />
            </div>
        </div>
    );
}

export default Overview
