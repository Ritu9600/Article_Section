import React from "react";
import {
  BarChart,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  Bar,
  ResponsiveContainer,
} from "recharts";
import styled from "styled-components";

function WeaknessGraph() {
  const data = [
    {
      topic: "Topic 1",
      correct: 50,
      incorrect: 25,
      skipped: 25,
    },
    {
      topic: "Topic 2",
      correct: 40,
      incorrect: 35,
      skipped: 25,
    },
    {
      topic: "Topic 3",
      correct: 20,
      incorrect: 45,
      skipped: 20,
    },
    {
      topic: "Topic 4",
      correct: 80,
      incorrect: 10,
      skipped: 10,
    },
    {
      topic: "Topic 5",
      correct: 95,
      incorrect: 5,
      skipped: 0,
    },
  ];

  return (
    <StyledCard>
      <ResponsiveContainer width="95%" height="95%">
        <BarChart
          data={data}
          barSize={10}
          margin={{ top: 30, bottom: 30, left: 20, right: 20 }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="topic" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Bar dataKey="correct" fill="#1BBC9B" />
          <Bar dataKey="incorrect" fill="#FE5252" />
          <Bar dataKey="skipped" fill="#B3DDD4" />
        </BarChart>
      </ResponsiveContainer>
    </StyledCard>
  );
}

export default WeaknessGraph;

const StyledCard = styled.div`
  width: 100%;
  height: 100%;
  filter: drop-shadow(0px 4px 24px rgba(0, 0, 0, 0.1));
  border-radius: 4px;
  overflow: auto;
  background-color: white;
  justify-content: center;
  align-items: center;
`;
