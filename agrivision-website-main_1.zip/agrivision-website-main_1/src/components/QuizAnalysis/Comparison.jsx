import React from 'react';
import styled from "styled-components";
import TablePage from './table';
import ComparisonGraph from "./ComparisonGraph";
import ComparisonConcepts from "./ComparisonConcepts";
import { Card, Row,  Col } from "reactstrap";
import "./Comparison.css";

function Comparison() {
	return (
		<Wrapper>
			<Row>
        <Col sm="8">
          <Card  className="card5">
             <ComparisonGraph className="graph1"/>
          </Card>
        </Col>
        <Col sm="4">
          <Card className="card6">
		  <TablePage className="table1"/>
          </Card>
        </Col>
       </Row>
	   <Row className="comparitive">
	   <ConceptsContainer>
		 <ComparisonConcepts />
	   </ConceptsContainer>
	 </Row>
		</Wrapper>
		
	);
}
export default Comparison;

const Wrapper = styled.div`
  height: 100%;
  display: flex;
  flex-direction: column;
  flex: 1;
`;

const ConceptsContainer = styled.div`
  flex-grow: 1;
  margin: 3%;
`;

/*
	<Wrapper>
      <RowOne>
		  <Card className="card1">
          <ComparisonGraph />
		</Card>
        <Card  className="card2">
            <TablePage />
          </Card>
      </RowOne>
      <RowTwo>
        <WeakConceptsContainer>
          <WeakConcepts />
        </WeakConceptsContainer>
      </RowTwo>
    </Wrapper>*/