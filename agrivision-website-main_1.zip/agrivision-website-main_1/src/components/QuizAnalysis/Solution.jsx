import React from "react";
import { useState, useEffect } from "react";
import styled from "styled-components";
import SolutionMain from "./SolutionMain";
import SolutionSide from "./SolutionSide";
import solutionsData from "./dummy-solution-data";
const numOfPhysicsQues = solutionsData.physics.length;
const numOfChemistryQues = solutionsData.chemistry.length;

const Solution = () => {
  const [isSideBarOpen, setIsSideBarOpen] = useState({
    byClick: true,
    bySize: false,
  });
  const [solutionArray, setSolutionArray] = useState(null);
  const handleToggleClick = () => {
    setIsSideBarOpen({ ...isSideBarOpen, byClick: !isSideBarOpen.byClick });
  };
  const createSolArray = (data) => {
    let solArray = [...data.physics, ...data.chemistry, ...data.maths]; //Hardcoding for now change after API is created
    let IndexedSolArray = solArray.map((ques, index) => {
      return { ...ques, index: index };
    });
    return IndexedSolArray;
  };

  useEffect(() => {
    setSolutionArray(createSolArray(solutionsData));
    console.log(solutionArray);
  }, []);

  return (
    <Wrapper>
      {solutionArray && (
        <Container>
          <SolutionMain
            isSideBarOpen={isSideBarOpen}
            handleToggleClick={handleToggleClick}
            numOfPhysicsQues={numOfPhysicsQues}
            numOfChemistryQues={numOfChemistryQues}
            solutions={solutionArray}
          />
          <SolutionSide
            isSideBarOpen={isSideBarOpen}
            setIsSideBarOpen={setIsSideBarOpen}
            handleToggleClick={handleToggleClick}
            solutions={solutionArray}
          />
        </Container>
      )}
    </Wrapper>
  );
};

const Container = styled.div`
  // height: calc(100% - 62px);
  height: 80vh;
  width: 100%;
  display: grid;
  grid-template-columns: 2.5fr 1fr;
  position: relative;
`;
const Wrapper = styled.div`
  width: 100%;
  height: 80vh;
`;
export default Solution;
