import React from "react";
import {
  BarChart,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  Bar,
  ResponsiveContainer,
} from "recharts";
import styled from "styled-components";

function ComparisonGraph() {
  const data = [
    {
      topic: "Topic 1",
      Marks: 65,
      Percentile: 89,
    },
    {
      topic: "topic 2",
      Marks: 45,
     Percentile: 76,
    },
    {
      topic: "topic 3",
      Marks: 35,
      Percentile: 95,
    },
    {
      topic: "topic 4",
      Marks: 70,
      Percentile: 90,
    },
    {
      topic: "topic 5",
      Marks: 85,
     Percentile: 80,
      
    },
    {
        topic: "topic 6",
        Marks: 35,
       Percentile: 70,
        
      },
      {
        topic: "topic 7",
        Marks: 25,
       Percentile: 50,
        
      },
  ];

  return (
    <StyledCard>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={data}
          barSize={10}
          margin={{ top: 30, bottom: 30, left: 20, right: 20 }}
        >
          <CartesianGrid strokeDasharray="2 2" />
          <XAxis dataKey="topic" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Bar dataKey="Marks" fill="#B3DDD4" />
          <Bar dataKey="Percentile" fill="#1AB294" />
        </BarChart>
      </ResponsiveContainer>
    </StyledCard>
  );
}

export default ComparisonGraph;

const StyledCard = styled.div`
  width: 100%;
  height: 100%;
  filter: drop-shadow(0px 4px 24px rgba(0, 0, 0, 0.1));
  border-radius: 4px;
  overflow: auto;
  background-color: white;
  justify-content: center;
  align-items: center;
`;
