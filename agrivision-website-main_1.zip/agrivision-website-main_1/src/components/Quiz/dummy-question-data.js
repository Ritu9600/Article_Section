const data = {
  physics: [
    {
      question:
        "The parliament act was passed in the year ....................... .",
      options: [1998, 1947, 1987, 1997],
    },
    {
      question:
        "The pssdent act dss passfd in tdfe ferear ....................... .",
      options: ["djsk", "1947", "ddssd", "sjdisjd"],
    },
    {
      question:
        "The pssdent acdstcd dss padsdssfd insdsd tdasasfe faweweerear ....................... .",
      options: ["3rd", "4th", "1987", "sdjsdh"],
    },
  ],
  chemistry: [
    {
      question:
        "4th quwst acdstcd dss padsdssfd insdsd tdasasfe faweweerear ....................... .",
      options: ["3rd", "4th", "1987", "sdjsdh"],
    },
    {
      question:
        "5th wiasu hisdiuas idu asui dui asow nld oasjdo iosd dos jdcsid odincos doi dosdjos osd dos ....................... .",
      options: [1998, 1947, 1987, 1997],
    },
  ],
  maths: [
    {
      question:
        "6th wiasu hisdiuas idu asui dui asow nld oasjdo iosd dos jdcsid odincos doisdsd dosdjos osd dos ....................... .",
      options: ["dsushd", 1947, 1987, "sdjijsd"],
    },

    {
      question:
        "7th wiasu hdsdsd sds ssdsdisdiuas idu asui dui asow nld oasjdo iosd dos jdcsid odincos doisdsd dosdjos osd dos ....................... .",
      options: ["dsushd", 1947, 1987, "sdjijsd"],
    },

    {
      question:
        "8th wiasu hsd dfdf dfdisdiuas idu asui dui asow nld oasjdo iosd dos jdcsid odincos doisdsd dosdjos osd dos ....................... .",
      options: ["dsushd", "sdksd", "sdksdj", "sdjijsd"],
    },
    {
      question:
        "9th widsd ds ds dsasu hsd dfdf dfdisdiuas idu asui dui asow nld oasjdo iosd dos jdcsid odincos doisdsd dosdjos osd dos ....................... .",
      options: ["dsushd", "sewedksd", "sdkdfdfsdj", "sdeweijsd"],
    },
    {
      question:
        "10th wiasdd fdf d fdf u hsd dfdf dfdisdiuas idu asui dui asow nld oasjdo iosd dos jdcsid odincos doisdsd dosdjos osd dos ....................... .",
      options: ["dsushd", "fdfdf", "sdkdfdfsdj", "sdjijsd"],
    },
  ],
};

export default data;
