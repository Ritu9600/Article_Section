import Layout from '../components/QuizAnalysis/Layout';
import { GlobalStyle } from './globalStyle';
import 'bootstrap/dist/css/bootstrap.min.css';

function QuizAnalysis() {
	return (
		<>
			<GlobalStyle />
			<Layout />
		</>
	);
}

export default QuizAnalysis;
