import Navbar from "../components/global/Navbar";
import Footer from "../components/global/Footer";
import HeroSection from '../components/PaymentPg/HeroSection';

function Payment() {
    return (
      <>
        <Navbar />
        <HeroSection />
        <Footer />
      </>
    );
  }
  
  export default Payment;
  