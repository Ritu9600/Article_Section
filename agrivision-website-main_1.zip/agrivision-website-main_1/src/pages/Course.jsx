import Layout from "../components/Course/Layout";
import Navbar from "../components/global/Navbar";

function Learning() {
  return (
    <>
      <Navbar course />
      <Layout />
    </>
  );
}

export default Learning;
